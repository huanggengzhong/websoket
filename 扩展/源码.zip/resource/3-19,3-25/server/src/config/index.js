const redisOptions = {
  host: "localhost",
  port: "6379",
}

module.exports = {
  redisOptions,
}
