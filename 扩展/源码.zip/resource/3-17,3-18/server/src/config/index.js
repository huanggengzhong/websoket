const redisOptions = {
  host: '39.98.179.40',
  port: '11050',
}

module.exports = {
  redisOptions
}