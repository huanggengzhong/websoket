const redis = require("redis")
const { promisifyAll } = require("bluebird")

const { redisOptions } = require("../config/index")

const redisClient = redis.createClient(redisOptions)
promisifyAll(redisClient)

// 对连接信息的监听
redisClient.on("connect", function() {
  console.log("redis client is connected to server!")
})

// 对错误日志的打印
redisClient.on("error", function(err) {
  console.log("redis client is error: " + err)
})

/**
 * setValue方法
 * @param {String} key 对象的属性
 * @param {String} value 对象的值 JSON.stringfy -> Object
 * @param {*} time 过期时间
 */
const setValue = function(key, value, time) {
  if (time) {
    redisClient.set(key, value, "EX", time, redis.print)
  } else {
    redisClient.set(key, value, redis.print)
  }
}

/**
 * getValue方法
 * @param {String} key
 * 返回是一个String，需要对对象形式的内容，使用JSON.parse
 */
const getValue = async function(key) {
  const result = await redisClient.getAsync(key)
  return result
}

module.exports = {
  setValue,
  getValue,
}
