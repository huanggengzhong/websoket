const WebSocket = require("ws")
const jwt = require("jsonwebtoken")
const { getValue, setValue } = require("./src/common/RedisConfig")

// setValue('itheima3', 'hello world! Itheima3 Print!')

// async function run() {
//   const result = await getValue('itheima3')
//   console.log('async result: ' + result)
// }

// run()

// 测试用的token
// const token = jwt.sign({
//   data: 'foobar'
// }, 'secret', { expiresIn: '1d' });

// console.log('token is:' + token);

const wss = new WebSocket.Server({ port: 8000 })

// 多聊天室的功能
// 记录房间ID -> roomid -> 指定对应的roomid进行广播
// 否则就广播到大厅 （default默认ID）

// 存放roomid： 1. ws对象上，存储在内存中 2.借助redis、mongodb这样的数据库进行持久化
// redis -> set -> group[roomid] -> 对应的会话ID
// mongodb -> 用户历史加入的房间/会话 -> 用户历史发消息 -> 收藏 等用户相关的需要持久化的数据
var group = {}
// 定时去检测客户端的时长
var timeInterval = 30000

// 提高服务的稳定性
// 检测客户端的连接 -> 定时器 -> 超过指定时间 -> 主动断开客户端的连接
wss.on("connection", function(ws, req) {
  // 初始化客户端的连接状态量
  ws.isAlive = true

  // console.log('a new client is connected!');
  ws.on("message", function(msg) {
    var msgObj = JSON.parse(msg)
    // 鉴权机制 -> 检验token的有效性
    if (msgObj.event === "auth") {
      // console.log('msg auth is: ' + msgObj.message)
      // 拿到token,并且去校验时效性
      jwt.verify(msgObj.message, "secret", function(err, decode) {
        if (err) {
          // websocket返回前台一个消息
          // console.log('auth error')
          return
        } else {
          // 鉴权通过的逻辑
          // 这里可以拿到decode，即payload里面的内容
          ws.isAuth = true
          return
        }
        console.log(JSON.stringify(decode))
      })
    }
    // 拦截，非鉴权的请求
    if (!ws.isAuth) {
      // ws.terminate()
      // 去给客户端发送重新鉴权的消息
      ws.send(
        JSON.stringify({
          event: "noauth",
          message: "please auth again, your token is expired!",
        })
      )
      return
    }
    if (msgObj.event === "heartbeat" && msgObj.message === "pong") {
      ws.isAlive = true
      return
    }
    if (msgObj.name) {
      ws.name = msgObj.name
    }
    if (typeof ws.roomid === "undefined" && msgObj.roomid) {
      ws.roomid = msgObj.roomid
      // 如果先前ws客户端是已经连接过了的，就不进行计数
      if (!msgObj.isConnected) {
        if (typeof group[ws.roomid] === "undefined") {
          group[ws.roomid] = 1
        } else {
          group[ws.roomid]++
        }
      } else {
        console.log("client is reconnect!")
      }
    }
    // 广播到其他的客户端
    wss.clients.forEach(function each(client) {
      msgObj.num = group[ws.roomid]
      msgObj.isConnected = ws.isConnected
      if (client.readyState === WebSocket.OPEN && client.roomid === ws.roomid) {
        client.send(JSON.stringify(msgObj))
      }

      // msgObj.num = wss.clients.size
      // // 广播给非自己的其他客户端
      // if (client.readyState === WebSocket.OPEN) {
      //   client.send(JSON.stringify(msgObj));
      // }
    })
  })
  // 客户端断开链接
  ws.on("close", function() {
    // console.log('one client is closed :' + ws);
    if (typeof ws.name !== "undefined") {
      group[ws.roomid]--
      // 广播到其他的客户端
      wss.clients.forEach(function each(client) {
        // 广播给非自己的其他客户端
        if (
          client !== ws &&
          ws.roomid === client.roomid &&
          client.readyState === WebSocket.OPEN
        ) {
          client.send(
            JSON.stringify({
              name: ws.name,
              event: "logout",
              num: group[ws.roomid],
            })
          )
        }
      })
    }
  })
})

const interval = setInterval(function() {
  // 遍历所有的客户端，发送一个ping/pong消息
  // 检测是否有返回，如果没有返回或者超时之后，主动断开与客户端的连接
  wss.clients.forEach(function each(ws) {
    if (ws.isAlive === false) {
      // console.log('client is disconneted!');
      group[ws.roomid]--
      return ws.terminate()
    }

    ws.isAlive = false
    // 主动发送ping/pong消息
    // 客户端返回了之后，主动设置isAlive的状态
    ws.send(
      JSON.stringify({
        event: "heartbeat",
        message: "ping",
      })
    )
  })
}, timeInterval)
