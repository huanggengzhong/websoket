// websocket客户端
const WebSocket = require('ws')

const ws = new WebSocket('ws://127.0.0.1:8000')

ws.on('open', function () {
  for (var i = 0; i < 3; i++) {
    ws.send('Hello from client: ' + i)
  }
  ws.on('message', function (msg) {
    console.log(msg)
  })
})