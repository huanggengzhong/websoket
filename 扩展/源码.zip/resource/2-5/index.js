// websocket server
const WebSocket = require('ws')

const wss = new WebSocket.Server({ port: 8000 })

wss.on('connection', function (ws) {
  ws.on('message', function (msg) {
    console.log(msg)
  })
  ws.send('Message from server!')
  ws.on('close', function () {
    console.log('close from client');
  })
})