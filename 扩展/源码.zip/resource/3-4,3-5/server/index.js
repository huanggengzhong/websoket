const WebSocket = require('ws')

const wss = new WebSocket.Server({ port: 8000 })

wss.on('connection', function (ws) {
  console.log('a new client is connected!');
  ws.on('message', function (msg) {
    var msgObj = JSON.parse(msg)
    if (msgObj.name) {
      ws.name = msgObj.name
    }
    // 广播到其他的客户端
    wss.clients.forEach(function each(client) {
      msgObj.num = wss.clients.size
      // 广播给非自己的其他客户端
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(msgObj));
      }
    });
  })
  ws.on('close', function () {
    console.log('one client is closed :' + ws);
    if (typeof ws.name !== 'undefined') {
      // 广播到其他的客户端
      wss.clients.forEach(function each(client) {
        // 广播给非自己的其他客户端
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            name: ws.name,
            event: 'logout',
            num: wss.clients.size
          }));
        }
      });
    }
  })
})